from iox import IoXWrapper
from nucore import Node
from .base_optimizer import BaseOptimizer, TESTING_MODE, OPT_OUT_DURATION
from opt_config.ven_settings import GridState, VENSettings, ComfortLevel
import asyncio

DUTY_CYCLE_PERIOD_SECONDS = None 
    
class SwitchOptimizer(BaseOptimizer):
    """
    Switch optimization algorithm for demand response across four grid states:
    Normal, Moderate, High, and Emergency (Special).
    
    The algorithm uses duty cycling to reduce load - switches are turned on/off
    in cycles based on the duty cycle percentage for the current grid state.
    If a customer manually changes state during an active optimization state, 
    the system opts out until the next day.
    """

    def __init__(self, ven_settings: VENSettings, node:Node, iox:IoXWrapper ):
        """
        Initialize the switch optimizer.
        
        Args:
            ven_settings: VENSettings instance containing configuration
            node: Node instance associated with this optimizer
            iox: IoXWrapper instance for interacting with IoX
        """
        # Track last applied switch settings to detect user changes
        self.duty_cycle_task = None
        self.last_applied_state = None
        self.current_state = None
        self.initial_state = None
        
        # Duty cycle control
        self.duty_cycle_running = False
        self.current_duty_cycle = None 
        self.cycle_period_seconds = DUTY_CYCLE_PERIOD_SECONDS 
        super().__init__(ven_settings, node, iox)

    def _update_settings(self):
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            # No running loop in this thread, so execute synchronously.
            asyncio.run(self._stop_duty_cycle())
        else:
            # Already inside an event loop, so schedule without nesting loops.
            loop.create_task(self._stop_duty_cycle())

    def _get_calibration_key(self):
        return 'duty_cycle_offsets'

    def _check_user_override (self, grid_state):
        """
        Check if the user has manually changed the dimmer level during an active optimization state.
        If detected, opt out of optimization until the next day.
        
        Args:
            grid_state: Current grid state
            
        Returns:
            True if user override detected and opted out, False otherwise
        """
        if not self.duty_cycle_running:
            return False

        # If we haven't applied any setpoints yet, no override possible
        if self.last_applied_state is not None and self.current_state is not None: 
            if self.last_applied_state != self.current_state:
                self.history.insert(self._get_device_name(), "Switch State", grid_state=grid_state, 
                                    requested_value=self.last_applied_state, current_value=self.current_state, 
                                    opt_status="User Override", opt_expires_at=self._get_opt_out_expiry().isoformat()) 
                return True
        
        return False
    
    def _adjust_level(self, level:float): 
        """
        Generate command to set the switch state 
        
        Args:
            level: New state value (0=OFF, >0=ON)
            
        Returns:
            new_level if successful, None otherwise
        """
        commands = []
        if level is not None: 
            command_id = 'DOF' if level == 0 else 'DON'
            commands.append({
                'device_id': self.node.address,
                'command_id': command_id, 
                'command_params': []
            })

        if len(commands) > 0: 
            response = self.iox.send_commands(commands)
            if response is None or len(response) == 0:
                self.print ('failed to send switch command to IoX.')
            #    return None
            if response[0] is None or response[0].status_code != 200:
                self.print ('failed to send switch command to IoX.')
            #    return None
        return level
    
    async def _run_duty_cycle(self, duty_cycle_percent: int):
        """
        Run duty cycle control loop.
        
        Args:
            duty_cycle_percent: Duty cycle percentage (0-100)
        """
        on_seconds = ((self.cycle_period_seconds * duty_cycle_percent) / 100)
        off_seconds = (self.cycle_period_seconds) - on_seconds
        
        self.print(f"starting duty cycle for {self.node.name}: "
              f"{duty_cycle_percent}% ({on_seconds}s ON, {off_seconds}s OFF)")
        
        try:
            while self.duty_cycle_running:
                # Turn OFF
                if off_seconds > 0 and self.duty_cycle_running:
                    self._adjust_level(0)
                    self.last_applied_state = 0
                    try:
                        await asyncio.sleep(off_seconds)
                    except asyncio.CancelledError:
                        break
                
                # Turn ON
                if on_seconds > 0:
                    self._adjust_level(1)
                    self.last_applied_state = 1
                    try:
                        await asyncio.sleep(on_seconds)
                    except asyncio.CancelledError:
                        break
                
        except asyncio.CancelledError:
            self.print(f"duty cycle cancelled for {self.node.name}")
            self._adjust_level(0)  # Turn off when stopping
            raise
    
    async def _start_duty_cycle(self, duty_cycle_percent: int):
        """Start duty cycle in background task"""
        if duty_cycle_percent >= 100:
            # Full power - just turn on
            await self._stop_duty_cycle()
            self._adjust_level(1)
            self.last_applied_state = 1
            return
        
        if duty_cycle_percent <= 0:
            # No power - turn off
            await self._stop_duty_cycle()
            self._adjust_level(0)
            self.last_applied_state = 0
            return
        
        # Update duty cycle
        self.current_duty_cycle = duty_cycle_percent
        
        # Start new task if not running
        if not self.duty_cycle_running:
            self.duty_cycle_running = True
            self.duty_cycle_task = asyncio.create_task(self._run_duty_cycle(duty_cycle_percent))
    
    async def _stop_duty_cycle(self):
        """Stop duty cycle and turn device off"""
        self.duty_cycle_running = False
        if self.duty_cycle_task and not self.duty_cycle_task.done():
            self.duty_cycle_task.cancel()
            try:
                await self.duty_cycle_task
            except asyncio.CancelledError:
                pass
        if self.initial_state is not None: 
            self._adjust_level(1 if self.initial_state>0 else 0)  # Ensure off
            self.last_applied_state = self.initial_state
            self.history.insert(
                self._get_device_name(), 
                "Duty Cycle", 
                grid_state=GridState.NORMAL,
                requested_value=self.initial_state,
                current_value=self.current_state,
                opt_status="Reset to Initial"
            )
        self.current_duty_cycle = None
                
    async def _optimize(self, grid_state):
        """
        Optimize switch using duty cycling based on current grid state.
        
        Algorithm:
        - Normal state (0): 100% duty cycle (always on)
        - Other states: Reduce duty cycle based on grid state severity
        
        Args:
            grid_state: Current grid state (0=Normal, 1=Moderate, 2=High, 3=Emergency)
            
        """

        if self.current_state == 0: 
            # Device is already off, no optimization needed
            return
        
        target_duty_cycle = self.get_offset_for_state(grid_state) 
        if target_duty_cycle > 100:
            target_duty_cycle = 100
        elif target_duty_cycle < 0:
            target_duty_cycle = 0

        if self.current_duty_cycle is not None:
            if self.current_duty_cycle == target_duty_cycle:
                self.print (f'target duty cycle unchanged from last applied value. Skipping optimization.')
                return
            else:
                #stop current duty cycle to change to new one
                self.print(f"stopping duty cycle run since the value has changed") 
                await self._stop_duty_cycle()
        
        msg=f'{self._get_device_name_only()}: optimizing with duty cycle {target_duty_cycle}%.'
        self._notify_device_ops(msg)
        
        # Record optimization
        self.history.insert(
            self._get_device_name(), 
            "Duty Cycle", 
            grid_state=grid_state, 
            requested_value=target_duty_cycle,
            current_value=self.current_duty_cycle, 
            opt_status="Optimized"
        )
        
        # Start or update duty cycling
        await self._start_duty_cycle(target_duty_cycle)
    
    async def _revert_to_initial_settings(self):
        """
        Revert switches to initial settings. 
        """
        await self._stop_duty_cycle()
        msg=f'{self._get_device_name_only()}: resetting to initial settings {self.last_applied_state}.'
        self._notify_device_ops(msg)
        self.last_applied_state = None 
        
    def _opt_out(self):
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            # No running loop in this thread, so execute synchronously.
            asyncio.run(self._stop_duty_cycle())
        else:
            loop.create_task(self._stop_duty_cycle())
    
    def _reset_opt_out(self):
        """
        Manually reset the opt-out status (e.g., for testing or user request).
        """
        self.last_applied_state = None
        # Stop duty cycling
        if hasattr(self, 'duty_cycle_task') and self.duty_cycle_task:
            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                # No running loop in this thread, so execute synchronously.
                asyncio.run(self._stop_duty_cycle())
            else:
                loop.create_task(self._stop_duty_cycle())

    async def _update_internal_state(self, property, value):
        """
        Args:
            property: property name from the event 
            value: the value for the property 
                'action': {
                    'value': str,
                    'uom': str or None,
                    'prec': str or None
                }
        """

        if property == 'ST':
            try:
                self.current_state = 0 if float(value['value']) == 0 else 1
                if self.initial_state is None or self.last_grid_state == GridState.NORMAL:
                    self.initial_state = self.current_state
            except Exception as e:
                self.print(f"error updating internal state for property {property}: {e}")