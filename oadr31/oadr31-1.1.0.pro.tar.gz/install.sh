#!/usr/bin/env bash
pip3 install pybind11 --user
pip3 install --no-cache-dir --no-build-isolation hnswlib --user
pip3 install -r requirements.txt --user
