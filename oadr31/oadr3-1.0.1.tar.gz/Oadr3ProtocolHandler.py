
import udi_interface, os, sys, json, time
from oadr30 import ValuesMap
from oadr30.config import OADR3Config, VTNRefImpl
from oadr30.vtn import VTNOps
from oadr30.ven import VEN
from oadr30.scheduler import EventScheduler
from oadr30.resource import Resource
LOGGER = udi_interface.LOGGER
Custom = udi_interface.Custom

class Oadr3ProtocolHandler:
    ##
    #Implementation and Protocol Handler class
    ##

    ##
    #The plugin has all the information that's stored in the json file.
    #The controller allows you to communicate with the underlying system (PG3).
    #

    def __init__(self, plugin):
        self.plugin = plugin
        ### In case you want to have a mapping of nodes, you can use something like this
        #self.nodes = {}
        ### See nodeAdded and nodeRemoved
        ###
        self.vtn_base_url=None
        self.client_id=None
        self.client_secret=None
        self.scale=None
        self.vtn=None
        self.ven=None
        self.scheduler=None

    def setController(self, controller):
        self.controller = controller

    ####
    #  You need to implement these methods!
    ####

    ####
    # MANDATORY
    # This method is called by IoX to set a property
    # in the node/device or service
    ####
    def setProperty(self, node, property_id, value):
        try:
            return True
        except Exception as ex:
            LOGGER.error(f'setProperty {property_id} failed .... ')
            return False
    
    ####
    # MANDATORY
    # This method is called by IoX to query a property
    # in the node/device or service. Return the actual 
    # value
    ####
    def queryProperty(self, node, property_id):
        try:
            return True
        except Exception as ex:
            LOGGER.error(f'queryProperty {property_id} failed .... ')
            return False

    ####
    # MANDATORY if and only if you have commands
    # This method is called by IoX to send a command 
    # to the node/device or service
    ####
    def processCommand(self, node, command_name, **kwargs):
        try:
            LOGGER.info(f"Processing command {command_name}") 
            if kwargs != None:
                for key, value in kwargs.items():
                    LOGGER.info(f"-param: {key}: {value}")
            return True
        except Exception as ex:
            LOGGER.error(str(ex))
            return False




#### Michel
    ####
    # MANDATORY if and only if you have commands
    # This method is called at start so that you can do whatever initialization
    # you need. If you return false, the status of the controller node shows 
    # disconnected. So, make sure you return the correct status.
    ####
    def start(self)->bool:


    

