import sqlite3
import os
from datetime import datetime
from typing import Optional, List, Dict, Any


HISTORY_DB_PATH = f"{os.getcwd()}/data/optimization_history.db"

class DeviceHistory:
    """
    SQLite database class for storing device optimization history.
    Tracks device state changes, requested values, and opt-out status.
    Singleton pattern ensures only one instance exists.
    """
    _instance = None
    
    def __new__(cls):
        """Singleton pattern - only one instance of DeviceHistory exists"""
        if cls._instance is None:
            cls._instance = super(DeviceHistory, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance
    
    def __init__(self, db_path: str = HISTORY_DB_PATH):
        """
        Initialize the device history database.
        
        Args:
            db_path: Path to the SQLite database file
        """
        if self._initialized:
            return
        
        # Create directory if it doesn't exist
        db_dir = os.path.dirname(db_path)
        if db_dir and not os.path.exists(db_dir):
            os.makedirs(db_dir)
        
        self.db_path = db_path
        self.conn = None
        self._initialize_db()
        self._initialized = True
    
    def _initialize_db(self):
        """Create the database table if it doesn't exist"""
        self.conn = sqlite3.connect(self.db_path)
        cursor = self.conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS optimization_history (
                timestamp TEXT NOT NULL,
                device_address TEXT NOT NULL,
                property_name TEXT NOT NULL,
                grid_state INTEGER NOT NULL,
                requested_value REAL,
                current_value REAL,
                opt_status TEXT NOT NULL,
                opt_expires_at TEXT,
                UNIQUE(device_address, timestamp)
            )
        ''')
        
        # Create indexes for faster queries
        cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_device_address 
            ON optimization_history(device_address)
        ''')
        
        cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_timestamp 
            ON optimization_history(timestamp)
        ''')
        
        cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_grid_state 
            ON optimization_history(grid_state)
        ''')
        
        self.conn.commit()
    
    def insert(self, device_address: str, property_name: str, 
               grid_state: int, requested_value: Optional[float], 
               current_value: Optional[float], opt_status: str,
               opt_expires_at: Optional[str] = None
               ) -> bool:
        """
        Insert a device history record.
        
        Args:
            timestamp: ISO format timestamp
            device_address: Device address/ID
            property_name: Human-readable property name
            grid_state: Grid state (0=Normal, 1=Moderate, 2=High, 3=Emergency)
            requested_value: Value requested by optimizer
            current_value: Current device value
            opt_status: Opt-out status ('active', 'opted_out', 'user_override', etc.)
            opt_expires_at: Opt-out expiration timestamp (ISO format)
            
        Returns:
            True if insert successful, False otherwise
        """
        try:
            timestamp = datetime.now().isoformat()
            
            cursor = self.conn.cursor()
            cursor.execute('''
                INSERT OR REPLACE INTO optimization_history 
                (timestamp, device_address, property_name, grid_state, 
                 requested_value, current_value, opt_status, opt_expires_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (timestamp, device_address, property_name, grid_state,
                  requested_value, current_value, opt_status, opt_expires_at))
            
            self.conn.commit()
            return True
        except Exception as ex:
            print(f"Failed to insert device history: {str(ex)}")
            return False
    
    def get_device_history(self, device_address: str, 
                          limit: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Get history for a specific device.
        
        Args:
            device_address: Device address to query
            limit: Maximum number of records to return (most recent first)
            
        Returns:
            List of history records as dictionaries
        """
        try:
            cursor = self.conn.cursor()
            query = '''
                SELECT timestamp, device_address, property_name, grid_state,
                       requested_value, current_value, opt_status, opt_expires_at
                FROM optimization_history
                WHERE device_address = ?
                ORDER BY timestamp DESC
            '''
            
            if limit:
                query += f' LIMIT {limit}'
            
            cursor.execute(query, (device_address,))
            
            columns = ['timestamp', 'device_address', 'property_name', 
                      'grid_state', 'requested_value', 'current_value', 'opt_status', 'opt_expires_at']
            
            return [dict(zip(columns, row)) for row in cursor.fetchall()]
        except Exception as ex:
            print(f"Failed to get device history: {str(ex)}")
            return []
    
    def get_recent_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """
        Get most recent history records across all devices.
        
        Args:
            limit: Maximum number of records to return
            
        Returns:
            List of history records as dictionaries
        """
        try:
            cursor = self.conn.cursor()
            cursor.execute('''
                SELECT timestamp, device_address, property_name, grid_state,
                       requested_value, current_value, opt_status, opt_expires_at
                FROM optimization_history
                ORDER BY timestamp DESC
                LIMIT ?
            ''', (limit,))
            
            columns = ['timestamp', 'device_address', 'property_name', 'grid_state', 
                      'requested_value', 'current_value', 'opt_status', 'opt_expires_at']
            
            return [dict(zip(columns, row)) for row in cursor.fetchall()]
        except Exception as ex:
            print(f"Failed to get recent history: {str(ex)}")
            return []
    
    def get_grid_state_history(self, grid_state: int, 
                               limit: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Get history for a specific grid state.
        
        Args:
            grid_state: Grid state to query (0-3)
            limit: Maximum number of records to return
            
        Returns:
            List of history records as dictionaries
        """
        try:
            cursor = self.conn.cursor()
            query = '''
                SELECT timestamp, device_address, property_name, grid_state,
                       requested_value, current_value, opt_status, opt_expires_at
                FROM optimization_history
                WHERE grid_state = ?
                ORDER BY timestamp DESC
            '''
            
            if limit:
                query += f' LIMIT {limit}'
            
            cursor.execute(query, (grid_state,))
            
            columns = ['timestamp', 'device_address', 'property_name', 'grid_state', 
                      'requested_value', 'current_value', 'opt_status', 'opt_expires_at']
            
            return [dict(zip(columns, row)) for row in cursor.fetchall()]
        except Exception as ex:
            print(f"Failed to get grid state history: {str(ex)}")
            return []
    
    def get_opted_out_devices(self) -> List[Dict[str, Any]]:
        """
        Get most recent record for each device that is currently opted out.
        
        Returns:
            List of devices with opt-out status
        """
        try:
            cursor = self.conn.cursor()
            cursor.execute('''
                SELECT h1.timestamp, h1.device_address, h1.property_name, h1.grid_state, 
                       h1.requested_value, h1.current_value, h1.opt_status, h1.opt_expires_at
                FROM optimization_history h1
                INNER JOIN (
                    SELECT device_address, MAX(timestamp) as max_timestamp
                    FROM optimization_history
                    GROUP BY device_address
                ) h2 ON h1.device_address = h2.device_address 
                    AND h1.timestamp = h2.max_timestamp
                WHERE h1.opt_status LIKE '%opted_out%' OR h1.opt_status LIKE '%override%'
                ORDER BY h1.timestamp DESC
            ''')
            
            columns = ['id', 'device_address', 'property_name', 'timestamp', 
                      'grid_state', 'requested_value', 'current_value', 'opt_status']
            
            return [dict(zip(columns, row)) for row in cursor.fetchall()]
        except Exception as ex:
            print(f"Failed to get opted out devices: {str(ex)}")
            return []
    
    def clear_old_records(self, days: int = 365) -> bool:
        """
        Delete records older than specified number of days.
        
        Args:
            days: Number of days to keep (delete older records)
            
        Returns:
            True if successful, False otherwise
        """
        try:
            cursor = self.conn.cursor()
            cutoff_date = datetime.now().replace(
                hour=0, minute=0, second=0, microsecond=0
            )
            cutoff_date = cutoff_date.replace(day=cutoff_date.day - days)
            
            cursor.execute('''
                DELETE FROM optimization_history
                WHERE timestamp < ?
            ''', (cutoff_date.isoformat(),))
            
            self.conn.commit()
            return True
        except Exception as ex:
            print(f"Failed to clear old records: {str(ex)}")
            return False
    
    def close(self):
        """Close the database connection"""
        if self.conn:
            self.conn.close()
    
    def __enter__(self):
        """Context manager entry"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit"""
        self.close()
