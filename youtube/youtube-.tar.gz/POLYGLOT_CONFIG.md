This plugin is very simple. All you have to do is to click on the Authenticate button if prompted.
Once authenticated, your playlists are downloaded to eisy and you can play them.

## Bluetooth:
If you want to connect eisy to your Bluetooth speaker, you need to also install the Bluetooth plugin.

## Features:
- Play in sequence or Shuffle
- Previous/Next
- Volume

## Multiple Instances:
You can have multiple instances of this plugin running where one outputs to the jack and one to your Bluetooth speakers.