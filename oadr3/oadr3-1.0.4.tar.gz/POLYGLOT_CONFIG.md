OpenADR 3.0 VEN Plugin for IoX


## Common Parameters:
1. Short Poll
    How often the VTN should be polled.

2. Long Poll
    Not used.

## Custom Parameters

1. VTN Base URL
    The base URL for the VTN

2. Client ID
    The client id used for OAUTH

3. Client Secret
    The client secret used for OAUTH

4. Duration Scale 
     Used to scale up/down the durations. i.e. 
     Scale=1/5, changes the duration to duration /= 5
     scale=5, changes the duration to duration *= 5. e.g.
     1/360 will convert each hour to 10 seconds.
     Mostly used for test purposes


## Important Note:
    You are part of the very elite team that gets to play with this plugin!

