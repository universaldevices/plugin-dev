#!/usr/bin/env python3
"""Pymodbus Synchronous Client Example.

An example of a single threaded synchronous client.

usage::

    tester.py [-h] [-c {tcp,udp,serial,tls}]
                    [-f {ascii,rtu,socket,tls}]
                    [-l {critical,error,warning,info,debug}] [-p PORT]
                    [--baudrate BAUDRATE] [--host HOST]

    -h, --help
        show this help message and exit
    -c, --comm {tcp,udp,serial,tls}
        set communication, default is tcp
    -f, --framer {ascii,rtu,socket,tls - default is socket}
        set framer, default depends on --comm
    -l, --log {critical,error,warning,info,debug}
        set log level, default is info
    -p, --port PORT
        set port
    --baudrate BAUDRATE
        set serial device baud rate
    --host HOST
        set host, default is 127.0.0.1

The corresponding server must be started before e.g. as:

    python3 server_sync.py

"""
import logging
import sys

import argparse
import logging
import os

from pymodbus import pymodbus_apply_logging_config


_logger = logging.getLogger(__file__)


def get_commandline(server=False, description=None, extras=None, cmdline=None):
    """Read and validate command line arguments."""
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument(
        "-c",
        "--comm",
        choices=["tcp", "udp", "serial", "tls"],
        help="set communication, default is tcp",
        dest="comm",
        default="tcp",
        type=str,
    )
    parser.add_argument(
        "-f",
        "--framer",
        choices=["ascii", "rtu", "socket", "tls"],
        help="set framer, default depends on --comm",
        dest="framer",
        type=str,
    )
    parser.add_argument(
        "-l",
        "--log",
        choices=["critical", "error", "warning", "info", "debug"],
        help="set log level, default is info",
        dest="log",
        default="info",
        type=str,
    )
    parser.add_argument(
        "-p",
        "--port",
        help="set port",
        dest="port",
        type=str,
    )
    parser.add_argument(
        "--baudrate",
        help="set serial device baud rate",
        default=9600,
        type=int,
    )
    parser.add_argument(
        "--host",
        help="set host, default is 127.0.0.1",
        dest="host",
        default=None,
        type=str,
    )
    if server:
        parser.add_argument(
            "--store",
            choices=["sequential", "sparse", "factory", "none"],
            help="set type of datastore",
            default="sequential",
            type=str,
        )
        parser.add_argument(
            "--slaves",
            help="set number of slaves, default is 0 (any)",
            default=0,
            type=int,
            nargs="+",
        )
        parser.add_argument(
            "--context",
            help="ADVANCED USAGE: set datastore context object",
            default=None,
        )
    else:
        parser.add_argument(
            "--timeout",
            help="ADVANCED USAGE: set client timeout",
            default=10,
            type=float,
        )
    if extras:
        for extra in extras:
            parser.add_argument(extra[0], **extra[1])
    args = parser.parse_args(cmdline)

    # set defaults
    comm_defaults = {
        "tcp": ["socket", 5020],
        "udp": ["socket", 5020],
        "serial": ["rtu", "/dev/ptyp0"],
        "tls": ["tls", 5020],
    }
    pymodbus_apply_logging_config(args.log.upper())
    _logger.setLevel(args.log.upper())
    if not args.framer:
        args.framer = comm_defaults[args.comm][0]
    args.port = args.port or comm_defaults[args.comm][1]
    if args.comm != "serial" and args.port:
        args.port = int(args.port)
    if not args.host:
        args.host = "" if server else "127.0.0.1"
    return args


def get_certificate(suffix: str):
    """Get example certificate."""
    delimiter = "\\" if os.name == "nt" else "/"
    cwd = os.getcwd().split(delimiter)[-1]
    if cwd == "examples":
        path = "."
    elif cwd == "sub_examples":
        path = "../../examples"
    elif cwd == "test":
        path = "../examples"
    elif cwd == "pymodbus":
        path = "examples"
    else:
        raise RuntimeError(f"**Error** Cannot find certificate path={cwd}")
    return f"{path}/certificates/pymodbus.{suffix}"

#try:
#    import helper
#except ImportError:
#    print("*** ERROR --> THIS EXAMPLE needs the example directory, please see \n\
#          https://pymodbus.readthedocs.io/en/latest/source/examples.html\n\
#          for more information.")
#    sys.exit(-1)

import pymodbus.client as modbusClient
from pymodbus import ModbusException


_logger = logging.getLogger(__file__)
_logger.setLevel("DEBUG")


def setup_sync_client(description=None, cmdline=None):
    """Run client setup."""
    args = get_commandline(
        server=False,
        description=description,
        cmdline=cmdline,
    )
    _logger.info("### Create client object")
    if args.comm == "tcp":
        client = modbusClient.ModbusTcpClient(
            args.host,
            port=args.port,
            # Common optional parameters:
            framer=args.framer,
            timeout=args.timeout,
            #    retries=3,
            #    retry_on_empty=False,y
            #    strict=True,
            # TCP setup parameters
            #    source_address=("localhost", 0),
        )
    elif args.comm == "udp":
        client = modbusClient.ModbusUdpClient(
            args.host,
            port=args.port,
            # Common optional parameters:
            framer=args.framer,
            timeout=args.timeout,
            #    retries=3,
            #    retry_on_empty=False,
            #    strict=True,
            # UDP setup parameters
            #    source_address=None,
        )
    elif args.comm == "serial":
        client = modbusClient.ModbusSerialClient(
            port=args.port,  # serial port
            # Common optional parameters:
            #    framer=ModbusRtuFramer,
            timeout=args.timeout,
            #    retries=3,
            #    retry_on_empty=False,
            #    strict=True,
            # Serial setup parameters
            baudrate=args.baudrate,
            #    bytesize=8,
            #    parity="N",
            #    stopbits=1,
            #    handle_local_echo=False,
            #    strict=True,
        )
    elif args.comm == "tls":
        client = modbusClient.ModbusTlsClient(
            args.host,
            port=args.port,
            # Common optional parameters:
            framer=args.framer,
            timeout=args.timeout,
            #    retries=3,
            #    retry_on_empty=False,
            # TLS setup parameters
            sslctx=modbusClient.ModbusTlsClient.generate_ssl(
                certfile=get_certificate("crt"),
                keyfile=get_certificate("key"),
            #    password=None,
            ),
            server_hostname="localhost",
        )
    return client

def get_input(prompt, cast_func=str):
    try:
        return cast_func(input(f"{prompt} : "))
    except ValueError:
#        print("Invalid input. Please try again.")
        return None

register:int = 0 
reg_type:str = "holding"
reg_count:int = 1
unit:int = 1
reg_types=[ "discrete", "coil", "input", "holding"]


def run_sync_client(client, modbus_calls=None):
    global register
    global reg_type
    global reg_types
    global reg_count
    global unit

    """Run sync client."""
    _logger.info("### Client starting")
    client.connect()
    if not client.connected:
        _logger.error("Could not connect to modbus host ... ")
        return  
    while True:
        tmp = get_input(f"Enter the register address ({register}) - enter -1 to exit", int)
        if tmp != None:
            register = tmp 
        if register == -1:
            break
        tmp = get_input(f"Enter the register type: [discrete (r) | coil (rw) | input (r) | holding (rw) | ] ({reg_type})", str)
        if tmp != None:
            reg_type = tmp 
        if not reg_type in reg_types:
            print(f"Invalid register type. Valid values are {reg_types}")
            continue
        tmp = get_input(f"Enter the number of registers to read ({reg_count})", str)
        if tmp != None:
            reg_count = tmp 
        tmp = get_input(f"Enter the unit number ({unit})", int)
        if tmp != None:
            unit = tmp 
        
        if modbus_calls:
            modbus_calls(client)

        try:
            response = None

            if reg_type == 'discrete':
                response = client.read_discrete_inputs(register, reg_count, unit=unit)
            elif reg_type == 'coil':
                response = client.read_coils(register, reg_count, unit=unit)
            elif reg_type == 'holding':
                response = client.read_holding_registers(register, reg_count, unit=unit)
            elif reg_type == 'input':
                response = client.read_input_registers(register, reg_count, unit=unit)
            
            if response.isError():
                LOGGER.error(f"Failed reading {self.register_type} @ {self.register_address}")
                return None
        except Exception as ex:
            _logger.error (str(ex))
            break
    
    client.close()
    _logger.info("### End of Program")



def run_a_few_calls(client):
    """Test connection works."""
    try:
        rr = client.read_coils(32, 1, slave=1)
        assert len(rr.bits) == 8
        rr = client.read_holding_registers(4, 2, slave=1)
        assert rr.registers[0] == 17
        assert rr.registers[1] == 17
    except ModbusException as exc:
        raise exc

def main(cmdline=None):
    """Combine setup and run."""
    testclient = setup_sync_client(
        description="Run synchronous client.", cmdline=cmdline
    )
    run_sync_client(testclient, None)


if __name__ == "__main__":
    main()