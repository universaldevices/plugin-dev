Very simple Modbus TCP implementation:
- All you need to provide is a JSON file describing the registers, unit of measure, names, and permissible values.
- You upload this JSON file using the Zip Upload button at the bottom of the Configuration screen.
- You also provide the host and port for your Modbus device
- If you have RTU, then in the protocol of the JSON file, add: 
"is_rtu": true (default is false)

## Parameters:

1. host
    - The IP address or hostname for your modbus device
2. port
    - The port for your modbus device





